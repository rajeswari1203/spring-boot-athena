package com.springboot.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import java.util.Properties;

import javax.swing.JOptionPane;

import com.amazonaws.athena.jdbc.AthenaDriver;
import com.amazonaws.auth.PropertiesFileCredentialsProvider;
import com.amazonaws.services.batch.model.ClientException;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.demo.model.Device;

@RestController
public class DeviceController {
	static final String athenaUrl = "jdbc:awsathena://athena.us-west-2.amazonaws.com:443";

	// public static void main(String[] args) {
	@RequestMapping("/getDeviceList")
	public List<Device> getDeviceList(@RequestParam(value = "selectedColumns", required = true) String selectedColumns,
			@RequestParam(value = "deviceId", required = false) String deviceId,
			@RequestParam("startTimeStamp") String startTimeStamp, @RequestParam("endTimeStamp") String endTimeStamp) {

		List<Device> deviceList = new ArrayList<Device>();

		Connection conn = null;
		Statement statement = null;
		// String deviceId = "BELT001";// args[0];
		// ,"deviceId":"BELT001","timestamp":"2016-12-21
		// String startTimeStamp = "2016-12-20";// args[1];
		// String endTimeStamp = "2016-12-22";// args[2];

		try {
			Class.forName("com.amazonaws.athena.jdbc.AthenaDriver");
			Properties info = new Properties();
			info.put("s3_staging_dir", "s3://athena-example/venkatbogam/");
			info.put("log_path", "/Users/Administrator/.athena/athenajdbc.log");
			info.put("aws_credentials_provider_class", "com.amazonaws.auth.PropertiesFileCredentialsProvider");
			info.put("aws_credentials_provider_arguments", "athenaCredentials.txt");

			System.out.println("Connecting to Athena...");
			conn = DriverManager.getConnection(athenaUrl, info);
			String tableTempName = "data_array_object";

			System.out.println("Listing tables...");
			// String sql = "SELECT * FROM athenapoc.elb_logs limit 10";
			statement = conn.createStatement();
			System.out.println("selectedColumns : " + selectedColumns);
			String[] columns = selectedColumns.split("~");
			StringBuffer qryColumns = new StringBuffer();
			for (String column : columns) {
				qryColumns.append(tableTempName).append(".").append(column);
				qryColumns.append(",");
			}
			String qryColumns1 = qryColumns.toString();
			System.out.println("qryColumns1 : " + qryColumns1);
			qryColumns1 = qryColumns1.substring(0, qryColumns1.length() - 1);
			System.out.println("qryColumns1 : " + qryColumns1);
			// selectedColumns=deviceId###timestamp
			// String qry = "select " + "data_array_object._id id," +
			// "data_array_object._rev rev,"
			// + "data_array_object.deviceId deviceId," +
			// "data_array_object.timestamp timestamp,"
			// + "data_array_object.orgid orgid "
			String qry = "select " + qryColumns1 + " from athena.athenajdbc CROSS JOIN UNNEST(docs) AS ttemp ("
					+ tableTempName + ") " + " where data_array_object.timestamp BETWEEN '" + startTimeStamp + "' AND '"
					+ endTimeStamp;
			System.out.println("qry : " + qry);

			if (deviceId != null)
				qry += "'and data_array_object.deviceId='" + deviceId + "'";
			else
				qry += "'";

			ResultSet rs = statement.executeQuery(qry);
			String deviceid;

			String timestamp;
			String id;
			String orgid;
			String magnetoX;

			while (rs.next()) {
				Device device = new Device();
				for (String column : columns) {
					System.out.print(column + " : " + rs.getString(column) + "\n");
					device.setVal(column, rs.getString(column));
				}
				// deviceid = rs.getString("deviceId");
				// timestamp = rs.getString("timestamp");
				// magnetoX =rs.getString("magnetoX");
				// id = rs.getString("_id");
				//
				// //orgid = rs.getString("orgid");
				// device.setId(id);
				// device.setDeviceId(deviceid);
				// device.setMagnetoX(magnetoX);
				// //device.setOrgid(orgid);
				// device.setTimestamp(timestamp);
				deviceList.add(device);
				// Display values
				// System.out.print("id: " + id + "\n");
				// System.out.print("deviceId: " + deviceid + "\n");
				// System.out.print("timestamp: " + timestamp + "\n");
				// System.out.print("orgid: " + orgid + "\n\n");

			}

			conn.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
			} catch (Exception ex) {

			}
			try {
				if (conn != null)
					conn.close();
			} catch (Exception ex) {

				ex.printStackTrace();
			}
		}
		System.out.printf("Finished connectivity test.");

		return deviceList;
	}

}
