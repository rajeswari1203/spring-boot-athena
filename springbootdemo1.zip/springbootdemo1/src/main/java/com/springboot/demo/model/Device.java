/**
 * 
 */
package com.springboot.demo.model;

/**
 * @author Administrator
 *
 */
public class Device {
	String deviceId;
	String timestamp;
	String id;
	String userId;
	String latitude;
	String pressureBackLeftVal;
	String humidityVal;
	String magnetoX;

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the pressureBackLeftVal
	 */
	public String getpressureBackLeftVal() {
		return pressureBackLeftVal;
	}

	/**
	 * @param pressureBackLeftVal the pressureBackLeftVal to set
	 */
	public void setpressureBackLeftVal(String pressureBackLeftVal) {
		this.pressureBackLeftVal = pressureBackLeftVal;
	}

	/**
	 * @return the humidityVal
	 */
	public String getHumidityVal() {
		return humidityVal;
	}

	/**
	 * @param humidityVal the humidityVal to set
	 */
	public void setHumidityVal(String humidityVal) {
		this.humidityVal = humidityVal;
	}

	/**
	 * @return the magnetoX
	 */
	public String getMagnetoX() {
		return magnetoX;
	}

	/**
	 * @param magnetoX the magnetoX to set
	 */
	public void setMagnetoX(String magnetoX) {
		this.magnetoX = magnetoX;
	}

/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the timestamp
	 */
	public String getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp
	 *            the timestamp to set
	 */
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public void setVal(String column, String value) {
//		String deviceId;
//		String timestamp;
//		String id;
//		String userId;
//		String latitude;
//		String prepssure;
//		String humidityVal;
//		String magnetoX;
		
		if ("deviceId".equalsIgnoreCase(column)) {
			setDeviceId(value);
		} else if ("timestamp".equalsIgnoreCase(column)) {
			setTimestamp(value);
		}else if ("_id".equalsIgnoreCase(column)) {
			setId(value);
		}else if ("userId".equalsIgnoreCase(column)) {
		   setUserId(value);
		}else if ("latitude".equalsIgnoreCase(column)) {
			setLatitude(value);
		}else if ("pressureBackLeftVal".equalsIgnoreCase(column)) {
			setpressureBackLeftVal(value);
		}else if ("humidityVal".equalsIgnoreCase(column)) {
			setHumidityVal(value);
		}else if ("magnetoX".equalsIgnoreCase(column)) {
			setMagnetoX(value);
		}
	}
//	@Override
//	public String toString() {
//	//	return "Device [id=" + id + ", deviceId=" + deviceId + ", timestamp=" + timestamp + ", userId="+ userId +",humidityval="+humidityVal +",pressureBackLeftVal="+pressureBackLeftVal+","]";
//	}
}
